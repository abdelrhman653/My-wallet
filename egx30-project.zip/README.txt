Add Environment Variable:
Name: OANOR_API_KEY
Value: الصق مفتاح Oanor هنا

هذه النسخة تستخدم Vercel Serverless Function في api/egx.js لحماية المفتاح.
بعد إضافة المتغير اعمل Redeploy.
